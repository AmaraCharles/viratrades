<!doctype html>
<html lang="en">


<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

<head>
    <!-- meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="author" content="Indonez">
    <meta name="theme-color" content="#00B276">
    <!-- preload assets -->
    <meta name="description" content="More than just Investment Delivering real-time Investment Solutions View all Services We set the pace, others follow As high-conviction investors, we refuse to follow the herd. Instead, we focus on stocks, commodities and real estate management that are out of favour with mainstream investors, as we believe that these offer the greatest potential for long-term" />
		<meta name="robots" content="max-image-preview:large" />
		<link rel="canonical" href="https://greenpointholdings.org/" />
	 <!--<meta property="og:image" content="https://example.com/your-logo.jpg"> -->
		<meta property="og:locale" content="en_US" />
		<meta property="og:site_name" content="Green Point Holdings LLC - Building Wealth, Empowering Futures" />
		<meta property="og:type" content="website" />
		<meta property="og:title" content="Home - Green Point Holdings LLC" />
		<meta property="og:description" content="More than just Investment Delivering real-time Investment Solutions View all Services We set the pace, others follow As high-conviction investors, we refuse to follow the herd. Instead, we focus on stocks, commodities and real estate management that are out of favour with mainstream investors, as we believe that these offer the greatest potential for long-term" />
		<meta property="og:url" content="https://greenpointholdings.org/" />
		<meta property="og:image" content="https://greenpointholdings.org/assets/images/1.png" />
		<!--<meta property="og:image:secure_url" content="https://greenpointholdings.org/assets/images/1.png" />-->
		<meta name="twitter:card" content="summary_large_image" />
		<meta name="twitter:title" content="Home - Green Point Holdings LLC" />
		<meta name="twitter:description" content="More than just Investment Delivering real-time Investment Solutions View all Services We set the pace, others follow As high-conviction investors, we refuse to follow the herd. Instead, we focus on stocks, commodities and real estate management that are out of favour with mainstream investors, as we believe that these offer the greatest potential for long-term" />
		<meta name="twitter:image" content="https://greenpointholdings.org/assets/images/1.png" />
		
    <link rel="preload" href="fonts/fa-brands-400.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="fonts/fa-solid-900.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="fonts/mulish-v3-latin-300.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="fonts/mulish-v3-latin-800.php" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="fonts/roboto-v20-latin-300.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="css/style.css" as="style">
    <link rel="preload" href="js/vendors/uikit.min.js" as="script">
    <link rel="preload" href="js/utilities.min.js" as="script">
    <link rel="preload" href="js/config-theme.js" as="script">
    <!-- stylesheet -->
    <link rel="stylesheet" href="css/style.css">
    <!-- uikit -->
    <script src="js/vendors/uikit.min.js"></script>
    <!-- favicon -->
    <link rel="shortcut icon" href="img/gp-fav.png" type="image/x-icon">
    <!-- touch icon -->
    <link rel="apple-touch-icon-precomposed" href="img/gp-fav.png">
    
    
    
    
    <title>Green Point Holdings</title>
    
    
       <link rel="shortcut icon" href="/img/gp-fav.png">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Nova+Square&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,500,500i,700&amp;display=swap" rel="stylesheet">

    <!--  CSS Style -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/webfonts/flaticon/flaticon.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="assets/css/layerslider.css">
    <link rel="stylesheet" href="assets/css/template.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/category/corporate-5.css">
    
    <style>
    @media screen and (max-width: 667px) {
        .ls-l{
            display: none;
        }
    }
</style>
</head>

<script src="//code.tidio.co/c1xhvhd3jjw5bql9prnozmdz2s7xlcll.js" async></script>
<body>
    <!-- page loader begin -->
    <div class="page-loader">
        <div></div>
        <div></div>
        <div></div>
    </div>
    <!-- page loader end -->
    <!-- header begin -->
 <header class="transparent-header nav-on-banner bg-dark" >
        <div class="navigation-header">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <nav class="navbar navbar-expand-lg nav-white nav-primary-hover nav-down-line-active py-2">
                            <a class="navbar-brand" href="index.php"><img class="nav-logo" src="assets/images/1.png" alt="Image not found !"></a>
                            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon flaticon-menu flat-small text-primary"></span>
						</button>

                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav ms-auto">
                                    <li class="nav-item">
                                        <a class="nav-link" href="index.php">Home</a> </li>
                                        
                                        
                                        
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="planning.php">
								Company
								</a>
                                        <ul class="dropdown-menu">
                                         
                                            <li><a class="dropdown-item" href="about.php">About</a></li>
                                            <li><a class="dropdown-item" href="faq.php">FAQ</a></li>
                                            <li><a class="dropdown-item" href="cert.pdf">Certificate of Incorporation</a></li>
                                         
                                        </ul>
                                    </li>
                                    
                                    <li class="nav-item ">
                                        <a class="nav-link " href="market.php">Market</a>
                                    </li>
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="planning.php">
								Planning Services
								</a>
                                        <ul class="dropdown-menu">
                                        
                                            <li><a class="dropdown-item" href="oil.php">Oil and Gas</a></li>
                                            <li><a class="dropdown-item" href="estate-planning.php">Estate Planning</a></li>
                                            <li><a class="dropdown-item" href="business-planning.php">Business Planning</a></li>
                                            <li><a class="dropdown-item" href="financial-planning.php">Financial Planning</a></li>
                                            <li><a class="dropdown-item" href="long-term-care.php">Long Term Care</a></li>
                                            <li><a class="dropdown-item" href="private-planning.php">Private Planning</a></li>
                                          
                                        </ul>
                                    </li>
                                    <li class="nav-item  ">
                                        <a class="nav-link" href="resources.php">Resources</a>
                                    </li>
                                     <li class="nav-item ">
                                        <a class="btn btn-success" href="https://ap.greenpointholdings.org/user/register">Get Started</a>
                                    </li>
                                  
                                </ul>
                               
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>

    
  
    <!-- header end -->	<!-- breadcrumb content end -->
	<main data-title="blog-single">
		<!-- blog content begin -->
		<div class="uk-section uk-margin-small-top">
			<div class="uk-container">
				<div class="uk-grid uk-flex uk-flex-center in-blog-1 in-article">
					<div class="uk-width-1-1 in-figure-available">
						<img class="uk-width-1-1 in-img-featured" src="img/crypto.jpg" alt="The typical U.S. household is spending $445 more a month due to inflation">
					</div>
					<div class="uk-width 1-1@m">
						<article class="uk-card-default uk-border-rounded in-flat-rounded-top">
							<div class="uk-card-body">
								
                       
							<h3 class="uk-margin-top uk-margin-medium-bottom">Buy Crypto</h3>
                            <p><h6> </h6> Cryptocurrencies have become a popular investment choice for many individuals around the world. If you’re looking to purchase cryptocurrency, it’s crucial to do so from trustworthy sources. Below are some reputable platforms where you can securely buy cryptocurrency: </p>
                  
                  
                  
                  
                           

                            <h5 class="uk-margin-small-bottom">Head</h5>
                            <p><h6>Binance:  </h6>  One of the world’s largest and most well-known exchanges, Binance offers a vast range of cryptocurrencies for purchase. Visit their website at [www.binance.com](www.binance.com).</p>
                            <p><h6> Coinbase:</h6> With a user-friendly interface, Coinbase is ideal for those new to the crypto world. Check them out at [www.coinbase.com](www.coinbase.com).  </p>
                            <p><h6>Kraken: </h6> Known for its security features and comprehensive crypto offerings, you can access Kraken at [www.kraken.com](www.kraken.com).
  </p>
                            <p><h6> Gemini:</h6> Co-founded by the Winklevoss twins, Gemini emphasizes both security and regulatory compliance. Find them at [www.gemini.com](www.gemini.com).  </p>
                            <p><h6> LocalBitcoins:</h6> If you’re looking to buy Bitcoin directly from sellers in your area, LocalBitcoins can be a great choice. Their platform can be accessed at [www.localbitcoins.com](www.localbitcoins.com).  </p>
                            <p><h6> </h6> More than just a cryptocurrency platform, eToro also offers trading in stocks and commodities. Their site is [www.etoro.com](www.etoro.com).  </p>
                            <p><h6>eToro: </h6>  </p>
                            <p><h6> </h6>When purchasing cryptocurrency, always ensure that you’re using secure and updated devices. Beware of phishing websites that might look like these platforms but have slightly different URLs. It’s always a good idea to bookmark the official sites and use those bookmarks to avoid potential scams.  </p>
							<p><h6>Bitstamp:</h6> One of the longest-standing crypto exchanges, Bitstamp has built a reputation for reliability. Their website is [www.bitstamp.net](www.bitstamp.net).</p>
                         



							
							


























							</div>
						
						</article>
					</div>
				</div>
			</div>
		</div>
		<!-- blog content end -->

	</main>
	<!-- footer begin -->
	<footer>
<div class="tradingview-widget-container" style="margin-bottom:-40px">

<script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
{
"symbols": [
  {
    "proName": "FOREXCOM:SPXUSD",
    "title": "S&P 500"
  },
  {
    "proName": "FOREXCOM:NSXUSD",
    "title": "US 100"
  },
  {
    "description": "",
    "proName": "NASDAQ:TSLA"
  },
  {
    "description": "Nividia",
    "proName": "NASDAQ:NVDA"
  },
  {
    "description": "Netflix",
    "proName": "NASDAQ:NFLX"
  },
  {
    "description": "Meta",
    "proName": "NASDAQ:META"
  }
],
"showSymbolLogo": true,
"colorTheme": "dark",
"isTransparent": true,
"displayMode": "adaptive",
"locale": "en"
}
</script>
</div>
		<div class="uk-section uk-section-secondary uk-light uk-margin-medium-top uk-background-contain uk-background-bottom-left" style="background-image: url(img/in-footer-background.png);">
			<div class="uk-container uk-margin-top">
				<div class="uk-grid" data-uk-grid="">
					<div class="uk-width-1-1 uk-width-expand@m">
						<div class="uk-child-width-1-3@s uk-margin-bottom" data-uk-grid="">
							<div>
								<ul class="uk-list">
									
									<li><a href="stocks.php">Stocks</a></li>
									<li><a href="forex.php">Forex</a></li>
                                   
                                    <li><a href="mutual-funds.php">Mutual Funds</a></li>
									<li><a href="real-estate.php">Real Estate</a></li>
									<li><a href="fixed-income.php">Fixed Income</a></li>
                                    <li><a href="gold.php">Gold Investment Option</a></li>
								</ul>
							</div>
							<div>
								<ul class="uk-list">
									<li><a href="about.php">About Us</a></li>
									<li><a href="resources.php">Resources</a></li>
									<li><a href="market.php">Market </a></li>
									<li><a href="faq.php">FAQ</a></li>
									<li><a href="cert.pdf">Certificate of Incorporation</a></li>
									<li><a href="/license">Get Trading License</a></li>
									
								</ul>
							</div>
							<div>
								<ul class="uk-list">
									<li><a href="oil.php">Oil & Gas</a></li>
									<li><a href="estate-planning.php">Estate Planning</a></li>
									<li><a href="business-planning.php">Business Planning</a></li>
									<li><a href="long-term-care.php">Long Term Care</a></li>
									<li><a href="financial-planning.php">Financial Planning</a></li>
									<li><a href="private-health-management.php">Private Health Management</a></li>
									
									<li><a href="planning.php">Planning Services</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="uk-width-1-1 uk-width-auto@m">
						<div class="uk-flex uk-flex-left uk-flex-right@m">
							<!-- social media begin -->
							<!-- <div class="uk-flex social-media-list">
								<div><a href="https://www.facebook.com/indonez" class="color-facebook text-decoration-none"><i class="fab fa-facebook-square"></i> Facebook</a></div>
								<div><a href="https://twitter.com/indonez_tw" class="color-twitter text-decoration-none"><i class="fab fa-twitter"></i> Twitter</a></div>
								<div><a href="https://www.instagram.com/indonez_ig" class="color-instagram text-decoration-none"><i class="fab fa-instagram"></i> Instagram</a></div>
								<div><a href="#some-link" class="color-youtube text-decoration-none"><i class="fab fa-youtube"></i> Youtube</a></div>
							</div> -->
							<!-- social media end -->
						</div>
						<div class="uk-flex uk-flex-left uk-flex-right@m uk-margin-top">
							<div>
								<!-- <a href="#"><img src="img/in-store-apple.png" alt="download-app" width="134" height="39"></a> -->
								<a class="uk-margin-small-left" href="https://play.google.com/store/apps/details?id=com.greenpoint.greenpointapp"><img src="img/in-store-google.png" alt="download-app" style="width:215px;height:59px"></a>
							</div>
						</div>
					</div>
				</div>
				<div class="uk-grid uk-margin-large-top uk-margin-bottom">
					<div class="uk-width-1-1">
						<div class="footer-logo">
							<img class="uk-margin-small-right in-offset-top-10 uk-display-block" src="img/2.png" alt="footer-logo" width="110" height="39" data-uk-img="">
						</div>
						<p class="uk-heading-line uk-margin-medium-bottom copyright-text"><span>Copyright ©2023-24 GreenPoint Holdings. All Rights Reserved.</span></p>
						 <p class="in-trading-risk">Green Point Holdings is a leading name in sustainable investments, committed to building a greener future. Disclaimer: Investment involves risks. Past performance is not indicative of future results. Please consider your investment goals and risk tolerance before investing. Contact us for personalized advice tailored to your financial journey.</p> 
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- footer end -->
	<!-- to top begin -->
	<a href="#" class="to-top uk-visible@m" data-uk-scroll>
		Top<i class="fas fa-chevron-up" ></i>
	</a>
	<!-- to top end -->
	<!-- javascript -->
	<script src="js/utilities.min.js"></script>
	<script src="js/config-theme.js"></script>
	
	    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/greensock.js"></script>
    <script src="assets/js/layerslider.transitions.js"></script>
    <script src="assets/js/layerslider.kreaturamedia.jquery.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.fancybox.min.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/mixitup.min.js"></script>
    <script src="assets/js/custom.js"></script>

    <script>
        $(document).ready(function() {

            $('#slider').layerSlider({
                sliderVersion: '6.0.0',
                type: 'fullsize',
                pauseOnHover: 'disabled',
                responsiveUnder: 0,
                layersContainer: 1200,
                maxRatio: 1,
                parallaxScrollReverse: true,
                hideUnder: 0,
                hideOver: 100000,
                skin: 'numbers',
                showBarTimer: false,
                showCircleTimer: false,
                thumbnailNavigation: 'disabled',
                allowRestartOnResize: true,
                skinsPath: 'assets/skins/',
            });

        });
    </script>
</body>


</html>