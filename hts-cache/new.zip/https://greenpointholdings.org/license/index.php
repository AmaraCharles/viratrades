<!doctype html>
<html lang="en">


<!-- Mirrored from www.indonez.com/html-demo/fina/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 27 Nov 2023 10:50:32 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

<head>
    <!-- meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="author" content="Indonez">
    <meta name="theme-color" content="#00B276">
    <!-- preload assets -->
    <meta name="description" content="More than just Investment Delivering real-time Investment Solutions View all Services We set the pace, others follow As high-conviction investors, we refuse to follow the herd. Instead, we focus on stocks, commodities and real estate management that are out of favour with mainstream investors, as we believe that these offer the greatest potential for long-term" />
		<meta name="robots" content="max-image-preview:large" />
		<link rel="canonical" href="https://greenpointholdings.org/" />
	
		<meta property="og:locale" content="en_US" />
		<meta property="og:site_name" content="Green Point Holdings LLC - Building Wealth, Empowering Futures" />
		<meta property="og:type" content="website" />
		<meta property="og:title" content="Home - Green Point Holdings LLC" />
		<meta property="og:description" content="More than just Investment Delivering real-time Investment Solutions View all Services We set the pace, others follow As high-conviction investors, we refuse to follow the herd. Instead, we focus on stocks, commodities and real estate management that are out of favour with mainstream investors, as we believe that these offer the greatest potential for long-term" />
		<meta property="og:url" content="https://greenpointholdings.org/" />
		<meta property="og:image" content="https://greenpointholdings.org/img/logo.png" />
		<meta property="og:image:secure_url" content="https://greenpointholdings.org/img/logo.png" />
		<meta name="twitter:card" content="summary_large_image" />
		<meta name="twitter:title" content="Home - Green Point Holdings LLC" />
		<meta name="twitter:description" content="More than just Investment Delivering real-time Investment Solutions View all Services We set the pace, others follow As high-conviction investors, we refuse to follow the herd. Instead, we focus on stocks, commodities and real estate management that are out of favour with mainstream investors, as we believe that these offer the greatest potential for long-term" />
		<meta name="twitter:image" content="https://greenpointholdings.org/img/gp-logo.png" />
		
    <link rel="preload" href="fonts/fa-brands-400.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="fonts/fa-solid-900.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="fonts/mulish-v3-latin-300.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="fonts/mulish-v3-latin-800.php" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="fonts/roboto-v20-latin-300.woff2" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="css/style.css" as="style">
    <link rel="preload" href="js/vendors/uikit.min.js" as="script">
    <link rel="preload" href="js/utilities.min.js" as="script">
    <link rel="preload" href="js/config-theme.js" as="script">
    <!-- stylesheet -->
    <link rel="stylesheet" href="css/style.css">
    <!-- uikit -->
    <script src="js/vendors/uikit.min.js"></script>
    <!-- favicon -->
    <link rel="shortcut icon" href="img/gp-fav.png" type="image/x-icon">
    <!-- touch icon -->
    <link rel="apple-touch-icon-precomposed" href="img/apple-touch-icon.png">
    <title>Green Point Holdings</title>
</head>

<body>
    <!-- page loader begin -->
    <div class="page-loader">
        <div></div>
        <div></div>
        <div></div>
    </div>
    <!-- page loader end -->
    <!-- header begin -->
    <header>
        <div class="uk-section uk-section-default uk-padding-remove-vertical uk-background-contain uk-background-top-left"
            style="background-image: url(img/in-header-background.png);">
            <div class="uk-container">
                <div class="uk-child-width-1-2@s in-top-header" data-uk-grid>
                    <div class="uk-flex uk-flex-center uk-flex-left@s">
                        <a class="uk-logo" href="index.php">
                            <img src="img/in-lazy.gif" data-src="img/gp-logo.png" alt="logo" width="130" height="36"
                                data-uk-img>
                        </a>
                    </div>
                    <div class="uk-grid-collapse uk-flex uk-flex-middle uk-flex-right uk-visible@s" data-uk-grid>
                        <div class="uk-margin-right in-language-select uk-visible@m">
                            <!-- <button class="uk-button uk-button-link" type="button"><i
                                    class="fas fa-globe"></i>English</button> -->
                            <div class="uk-box-shadow-medium"
                                data-uk-dropdown="mode: click; offset: 16; pos: bottom-right; boundary: !.in-language-select; animation: uk-animation-slide-top-small; duration: 300">
                                <!-- <ul class="uk-nav uk-dropdown-nav">
                                    <li><a href="#"><img src="img/in-lazy.gif" data-src="img/in-flag-uk.svg" alt="flag"
                                                width="14" height="14" data-uk-img>English</a></li>
                                    <li><a href="#"><img src="img/in-lazy.gif" data-src="img/in-flag-id.svg" alt="flag"
                                                width="14" height="14" data-uk-img>Indonesia</a></li>
                                </ul> -->
                            </div>
                            <a href="https://ap.greenpointholdings.org/user/login" class="uk-button uk-button-link"><i
                                    class="fas fa-sign-in-alt"></i>Login</a>
                        </div>
                        <div>
                            <!-- <h2 class="in-header-phone">1-800-123-4567</h2> -->
                        </div>
                    </div>
                </div>
                <hr>
            </div>
            <nav class="uk-navbar-container" data-uk-sticky="show-on-up: true; animation: uk-animation-slide-top;">
                <div class="uk-container" data-uk-navbar>
                    <div class="uk-navbar-left uk-visible@m">
                        <ul class="uk-navbar-nav">
                            <li><a href="../index.php">Home</a></li>

                            <li><a href="#">Company<span data-uk-navbar-parent-icon></span></a>
                                <div class="uk-navbar-dropdown">
                                    <ul class="uk-nav uk-navbar-dropdown-nav">
                                        <li><a href="../about.php">About</a></li>
                                        <li><a href="../faq.php">FAQ</a></li>
                                        <li><a href="../cert.pdf">Certificate Of Incorporation</a></li>
                                        
                                    </ul>
                                </div>
                            </li>
                            <li><a href="../market.php">Markets</a>
                            </li>

                            <li><a href="planning.php">Planning Services<span data-uk-navbar-parent-icon></span></a>
                                <div class="uk-navbar-dropdown">
                                    <ul class="uk-nav uk-navbar-dropdown-nav">
                                        <li><a href="../oil.php">Oil & Gas</a></li>
                                        <li><a href="../estate-planning.php">Estate Planning</a></li>
                                        <li><a href="../business-planning.php">Business Planning</a></li>
                                        <li><a href="../financial-planning.php">Financial Planning</a></li>
                                        <li><a href="../long-term-care.php">Long Term Care</a></li>
                                        <li><a href="../private-health-management.php">Private Health Planning</a></li>
                                    </ul>
                                </div>
                            </li>
                            <!-- <li><a href="planning.php">Planning Services</a>
                            </li> -->
                            <li><a href="../resources.php">Resources</a>
                            </li>
                           
                        </ul>
                    </div>
                    <div class="uk-navbar-right"
                        data-logo-inverse="filename: img/gp-side-fav.png; width: 70; height: 70; inject: true">
                        <div class="uk-navbar-item in-optional-nav">
                            <div>
                                <a href="https://ap.greenpointholdings.org/user/login"
                                    class="uk-button uk-button-default uk-border-rounded uk-margin-small-right uk-visible@s">Login</a>
                                <a href="https://ap.greenpointholdings.org/user/register" class="uk-button uk-button-primary uk-border-rounded">Create account</a>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <!-- header end --><main>
    <!-- section content begin -->
    <div class="uk-section in-fina-20 uk-padding-large uk-background-cover"
        style="background-image: url(img/gp-tl.png);" data-uk-parallax="bgy: -300">
        <div class="uk-container">
            <div class="uk-grid-large uk-flex uk-flex-middle" data-uk-grid>
                <div class="uk-width-1-1 uk-width-1-2@m uk-light">
                    <div class="uk-margin-right">
                        <span class="uk-label uk-label-success uk-text-uppercase uk-border-pill">About Us</span>
                        <h2 class="uk-margin-top uk-margin-remove-bottom">CRYPTO LICENSE</h2>
                            <p>
Cryptocurrencies have already become a full-fledged alternative to fiat money. The crypto business has appeared relatively recently. Most countries have already introduced changes to their legislation to regulate this type of economic activity. In order to legally engage in the crypto business, you must obtain an appropriate cryptocurrency broker license.</p>
                        <!-- <p class="uk-text-lead">

                            Helping people enhance their wealth We attribute our long-term success to our commitment to
                            always putting clients’ interests first.</p>
                        <a class="uk-button uk-button-text" href="https://ap.greenpointholdings.org/user/login">Get
                            Started</a> -->

                    </div>
                </div>
              
            </div>
        </div>
    </div>




    <div class="uk-section in-fina-14">
       

.








        <div class="uk-container">
         
            <h1 class="uk-margin-small-bottom">Process To Obtain Crypto License</h1>
          
   
					      <p class="uk-text-lead uk-text-muted uk-margin-remove-top">
To obtain a crypto trading license one must first select a jurisdiction and then collect some documents which include your information, after that you need to pay a state fee and wait for a cryptocurrency license Which gives you the option to get the crypto license in the UK, USA, Estonia and Malta.</p>
            <div class="uk-grid-match" data-uk-grid>
                <div class="uk-width-1-2@m">
                    <div class="uk-card uk-card-default uk-card-body uk-box-shadow-small uk-border-rounded">
                        <h4>Estonia processing time 7-14days.</h4>
                        <ul class="uk-list in-list-check">
                            <li> 0% tax on profit gains

</li>
                            <li>No annual license fee.</li>
                            <li>Availability of legislation for accounting declaration of crypto assets.</li>
                            <li>Highest number of licenses issued.</li>
                        </ul>

                    </div>
                </div>
                
               
                <div class="uk-width-1-2@m">
                    <div class="uk-card uk-card-default uk-card-body uk-box-shadow-small uk-border-rounded">
                        <h4>Malta processing time 1 – 3 months</h4>
                        <ul class="uk-list in-list-check">
                            <li>First European country to adopt crypto legislation.

                        <li>Prestige and worldwide recognition of the jurisdiction.
</li>
                            <li>Progressive state approach to cryptocurrencies.
</li>
                        

                        </ul>

                    </div>
                </div>
            






                 <div class="uk-width-1-2@m">
                    <div class="uk-card uk-card-default uk-card-body uk-box-shadow-small uk-border-rounded">
                        <h4>  UK processing time 6 months</h4>
                        <ul class="uk-list in-list-check">
                            <li>Lower tax rate than in most countries</li>
                            <li>No restrictions on mining.</li>
                            <li>Ability to obtain UK residency.</li>
                            <li>Prestige and worldwide recognition of the jurisdiction.</li>
                        </ul>

                    </div>
                </div>
                <div class="uk-width-1-2@m">
                    <div class="uk-card uk-card-default uk-card-body uk-box-shadow-small uk-border-rounded">
                        <h4>USA processing time 30 days.</h4>
                        <ul class="uk-list in-list-check">
                            <li>Foreign exchange services.</li>
                            <li>Background checks and the provision of prepaid access.</li>
                           
                        </ul>
                        <a class="uk-button uk-button-text" href="#">View pricing & rates</a>
                    </div>
                </div> 
            </div>

        </div>
    </div>
            <div class="uk-section in-fina-14">
       

.








        <div class="uk-container">
               <div class="uk-width-1-1 uk-width-1-1@m uk-margin-small-bottom">
						<div class="uk-card uk-card-default uk-card-body uk-box-shadow-small uk-border-rounded">
							<h4>Request License</h4>
							<form class="uk-grid uk-form" action="mail.php" method="POST">
								<div class="uk-margin-small uk-width-1-1 uk-inline">
									<input class="uk-input uk-border-rounded" id="fullname" name="name"  type="text" placeholder="Full name">
								</div>
								<div class="uk-margin-small uk-width-1-1 uk-inline">
									<input class="uk-input uk-border-rounded" id="emailaddress" name="email"  type="email" placeholder="Email address">
								</div>
								<div class="uk-margin-small uk-width-1-1 uk-inline">
									<input class="uk-input uk-border-rounded"  type="text" name="subject"placeholder="Subject">
								</div>
									<div class="uk-margin-small uk-width-1-1 uk-inline">
									<textarea rows="6" class="uk-textarea uk-border-rounded"  type="text" name="msg" placeholder="Message"></textarea>
								</div>
								<div class="uk-margin-small uk-width-1-1">
									<button class="uk-button uk-width-1-1 uk-button-primary uk-border-rounded uk-float-left" type="submit" name="submit">Request License</button>
								</div>
							</form>
						</div>
					</div>
					</div>
					</div>

</main>
<footer>
<div class="tradingview-widget-container" style="margin-bottom:-40px">

<script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
{
"symbols": [
  {
    "proName": "FOREXCOM:SPXUSD",
    "title": "S&P 500"
  },
  {
    "proName": "FOREXCOM:NSXUSD",
    "title": "US 100"
  },
  {
    "description": "",
    "proName": "NASDAQ:TSLA"
  },
  {
    "description": "Nividia",
    "proName": "NASDAQ:NVDA"
  },
  {
    "description": "Netflix",
    "proName": "NASDAQ:NFLX"
  },
  {
    "description": "Meta",
    "proName": "NASDAQ:META"
  }
],
"showSymbolLogo": true,
"colorTheme": "dark",
"isTransparent": true,
"displayMode": "adaptive",
"locale": "en"
}
</script>
</div>
		<div class="uk-section uk-section-secondary uk-light uk-margin-medium-top uk-background-contain uk-background-bottom-left" style="background-image: url(img/in-footer-background.png);">
			<div class="uk-container uk-margin-top">
				<div class="uk-grid" data-uk-grid="">
					<div class="uk-width-1-1 uk-width-expand@m">
						<div class="uk-child-width-1-3@s uk-margin-bottom" data-uk-grid="">
							<div>
								<ul class="uk-list">
									
									<li><a href="../stocks.php">Stocks</a></li>
									<li><a href="../forex.php">Forex</a></li>
                                   
                                    <li><a href="../mutual-funds.php">Mutual Funds</a></li>
									<li><a href="../real-estate.php">Real Estate</a></li>
									<li><a href="../fixed-income.php">Fixed Income</a></li>
                                    <li><a href="../gold.php">Gold Investment Option</a></li>
								</ul>
							</div>
							<div>
								<ul class="uk-list">
									<li><a href="../about.php">About Us</a></li>
									<li><a href="../resources.php">Resources</a></li>
									<li><a href="../market.php">Market </a></li>
									<li><a href="../faq.php">FAQ</a></li>
									<li><a href="../cert.pdf">Certificate of Incorporation</a></li>
									
								</ul>
							</div>
							<div>
								<ul class="uk-list">
									<li><a href="../oil.php">Oil & Gas</a></li>
									<li><a href="../estate-planning.php">Estate Planning</a></li>
									<li><a href="../business-planning.php">Business Planning</a></li>
									<li><a href="../long-term-care.php">Long Term Care</a></li>
									<li><a href="../financial-planning.php">Financial Planning</a></li>
									<li><a href="../private-health-management.php">Private Health Management</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="uk-width-1-1 uk-width-auto@m">
						<div class="uk-flex uk-flex-left uk-flex-right@m">
							<!-- social media begin -->
							<!-- <div class="uk-flex social-media-list">
								<div><a href="../https://www.facebook.com/indonez" class="color-facebook text-decoration-none"><i class="fab fa-facebook-square"></i> Facebook</a></div>
								<div><a href="../https://twitter.com/indonez_tw" class="color-twitter text-decoration-none"><i class="fab fa-twitter"></i> Twitter</a></div>
								<div><a href="../https://www.instagram.com/indonez_ig" class="color-instagram text-decoration-none"><i class="fab fa-instagram"></i> Instagram</a></div>
								<div><a href="../#some-link" class="color-youtube text-decoration-none"><i class="fab fa-youtube"></i> Youtube</a></div>
							</div> -->
							<!-- social media end -->
						</div>
						<div class="uk-flex uk-flex-left uk-flex-right@m uk-margin-top">
							<div>
								<!-- <a href="../#"><img src="img/in-store-apple.png" alt="download-app" width="134" height="39"></a> -->
								<a class="uk-margin-small-left" href="https://play.google.com/store/apps/details?id=com.greenpoint.greenpointapp"><img src="img/in-store-google.png" alt="download-app" style="width:215px;height:59px"></a>
							</div>
						</div>
					</div>
				</div>
				<div class="uk-grid uk-margin-large-top uk-margin-bottom">
					<div class="uk-width-1-1">
						<div class="footer-logo">
							<img class="uk-margin-small-right in-offset-top-10 uk-display-block" src="img/2.png" alt="footer-logo" width="110" height="39" data-uk-img="">
						</div>
						<p class="uk-heading-line uk-margin-medium-bottom copyright-text"><span>Copyright ©2023-24 GreenPoint Holdings. All Rights Reserved.</span></p>
						 <p class="in-trading-risk">© 2023 Green Point Holdings. All rights reserved. Green Point Holdings is a leading name in sustainable investments, committed to building a greener future. Disclaimer: Investment involves risks. Past performance is not indicative of future results. Please consider your investment goals and risk tolerance before investing. Contact us for personalized advice tailored to your financial journey.</p> 
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- footer end -->
	<!-- to top begin -->
	<a href="../#" class="to-top uk-visible@m" data-uk-scroll>
		Top<i class="fas fa-chevron-up" ></i>
	</a>
	<!-- to top end -->
	<!-- javascript -->
	<script src="js/utilities.min.js"></script>
	<script src="js/config-theme.js"></script>
</body>


</html>